use std::io;

fn main() {

    let emp_name = String::new();
    let mut hrs_worked = String::new();
    let work_status = String::new();
    let gross_salary = String::new();
    let net_pay = String::new();


    loop{

        println!("Do you work here? (yes/no)");
        io::stdin().read_line(&mut work_status).expect("Not a valid string");
        let work_status = work_status.trim().to_lowercase();


        println!("What is your name?");
        io::stdin().read_line(&mut emp_name).expect("Not a valid string");
        let emp_name = emp_name.trim().parse().expect("Not a employee name");

        println!("How many hrs do you work?");
        io::stdin().read_line(&mut hrs_worked).expect("Not a valid string");
        let hrs_worked = hrs_worked.trim().parse().expect("Not an answer");

        if hrs_worked <= 40 {
        let mut gross_salary:i32 = 3_000 * hrs_worked;

        println!("Your gross salary is {}", gross_salary);
    }

        else if hrs_worked > 40 {
        let mut gross_salary:i32 = 4_500 * hrs_worked;

        println!("Your gross salary is {}", gross_salary);
    }

        if gross_salary > 100_000 {
        let mut net_pay:i32 = gross_salary - 2_000;

        println!("Your net pay is: {}", net_pay);
    }

        if work_status == "yes" {
            continue;
        }

        if work_status == "no" {
            break;
        }


        }
    }
