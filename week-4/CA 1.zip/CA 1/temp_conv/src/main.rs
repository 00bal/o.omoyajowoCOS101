use std::io;

fn main() {

    let mut c = String::new();
        loop{
             println!("Enter temperature");
    io::stdin().read_line(&mut c).expect("Not a valid string");
    let c:f32 = c.trim().parse().expect("Not a valid temperature");

    let f:f32 = (9.0 / 5.0) * c + 32.0;
    println!("The temperature in Fahrenheit is: {} ", f);

    let k:f32 = c + 273.15;
    println!("The temperature in kelvin is: {} ", k); 

    if c > -273.0 {
     break;
    }

    if c < - 273.0{
    println!("Not valid");
    continue
    }
}

 
if c < 0.0 {
    println!("Freezing point temperatures recorded");
}

else if c >= 0.0 {
    println!("Normal range temperature recorded");
}

else if c > 30.0 {
    println!("Hot temperatures recorded");
}

else {
    println!("Invalid temperature");
}

}